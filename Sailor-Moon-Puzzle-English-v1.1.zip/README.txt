SAILOR MOON PUZZLE — ENGLISH v1.1
2026-10-25

For Bishoujo Senshi Sailor Moon S: Kondo wa Puzzle de Oshioki yo!! (Japan).
Unofficial Super Famicom / SNES fan translation.

WHAT CHANGED IN v1.1
Adds the white SuperWes startup screen with the original shield and this notice:
A fan translation project by SuperWes.
This game was machine translated by AI, if that isn’t for you please turn it off.

Release held input, then press and release any Player 1 button to continue.
No timeout or button prompt. No additional ROM capacity.
Polishes number labels and layout:
- STAGE appears above its number, and results read STAGE <number> CLEAR.
- Win counters read W:<number> instead of <number>W.
- Stage numbers, scores, timers, countdowns, and music/sound indices use
  the same English font as their labels, with consistent digit spacing.
Password data, number values, match rules, and other translation text are unchanged.

EXISTING v1.0 FEATURES
Passwords now use ten English letters, digits, or punctuation characters.
The 82 original password symbols map one-for-one to A–Z, a–z, 0–9, and:
! # $ % & ( ) * + , - . / : = ? @ [ ] _
Uppercase and lowercase are DIFFERENT: passwords are case-sensitive.
The underlying password data, stages, verification, and controls are unchanged.
The translation covers: 92 scripts, menus, results, quotes,
endings, credits, and password interface. Japanese logos and voices remain.

PASSWORDS
Press Select at character selection to open password entry.
D-pad selects a character; A enters it. B moves back one password position.
Start or DONE checks the password. Select or BACK leaves the screen.
<< and >> move the insertion position. There are TEN characters.
Example: the earlier numeric tokens 36 01 57 57 70 26 10 05 46 78 become jA44*ZJEt?
Use password-key.csv to convert Japanese passwords or the old numeric tokens.
Do not type the old twenty-digit notation directly into the new screen.

APPLY THE PATCH
Extract the ZIP. Apply the BPS to a CLEAN, unheadered Japanese ROM:
  Size: 524,288 bytes
  CRC32: 10F03E3C
  SHA256: e109d83aef2b734f30391c7e1c3741366f816d8e5f8ccc4e86990b0eafb083e7
Do not apply it on top of any earlier patched ROM. The patch includes all earlier translation work.
Output size: 2,097,152 bytes; CRC32: FEDDB3E2.
Start from a fresh boot. Older save states can restore the old font/graphics.
No ROM is included in the ZIP. The separately built local .sfc is for testing.

POLYMEGA
Put the extracted .bps in a folder called patch on USB or SD media, then
choose Select Patch from the installed game's Play menu. Match the game
revision above. https://polymega.com/pages/frequently-asked-questions
Wes successfully playtested v1.1 on 2026-10-25 and reported that it worked
fine and seemed better. The platform was not separately specified in that
report. An earlier build was tested with an original cartridge on Polymega.
See TESTING.txt for emulator checks and the limits of the playtest coverage.

BUILD / TEST
python3 source/build_full.py "clean.sfc"
python3 source/check_build.py "clean.sfc"
See TESTING.txt for coverage. Superseded builds are kept in ../archive/.
