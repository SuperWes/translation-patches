SAILOR MOON PUZZLE — ENGLISH v1.0
2026-10-19

For Bishoujo Senshi Sailor Moon S: Kondo wa Puzzle de Oshioki yo!! (Japan).
Unofficial Super Famicom / SNES fan translation.

WHAT CHANGED
Passwords now use ten English letters, digits, or punctuation characters.
The 82 original password symbols map one-for-one to A–Z, a–z, 0–9, and:
! # $ % & ( ) * + , - . / : = ? @ [ ] _
Uppercase and lowercase are DIFFERENT: passwords are case-sensitive.
The underlying password data, stages, verification, and controls are unchanged.
The translation covers: 92 scripts, menus, results, quotes,
endings, credits, and password interface. Japanese logos and voices remain.

PASSWORDS
Press Select at character selection to open password entry.
D-pad selects a character; A enters it. B moves back one password position.
Start or DONE checks the password. Select or BACK leaves the screen.
<< and >> move the insertion position. There are TEN characters.
Example: the earlier numeric tokens 36 01 57 57 70 26 10 05 46 78 become jA44*ZJEt?
Use password-key.csv to convert Japanese passwords or the old numeric tokens.
Do not type the old twenty-digit notation directly into the new screen.

APPLY THE PATCH
Extract the ZIP. Apply the BPS to a CLEAN, unheadered Japanese ROM:
  Size: 524,288 bytes
  CRC32: 10F03E3C
  SHA256: e109d83aef2b734f30391c7e1c3741366f816d8e5f8ccc4e86990b0eafb083e7
Do not apply it on top of any earlier patched ROM. The patch includes all earlier translation work.
Output size: 2,097,152 bytes; CRC32: B259BF96.
Start from a fresh boot. Older save states can restore the old font/graphics.
No ROM is included in the ZIP. The separately built local .sfc is for testing.

POLYMEGA
Put the extracted .bps in a folder called patch on USB or SD media, then
choose Select Patch from the installed game's Play menu. Match the game
revision above. https://polymega.com/pages/frequently-asked-questions
Wes tested an earlier build with an original cartridge on Polymega. The final
letter-password build has emulator verification; its new font still needs
a Polymega check.

BUILD / TEST
python3 source/build_full.py "clean.sfc"
python3 source/check_build.py "clean.sfc"
See TESTING.txt for coverage. Superseded builds are kept in ../archive/.
