BE-BOP HIGH SCHOOL — ENGLISH 1.0
Translation project: SuperWes, with AI assistance from Codex.

Apply Be-Bop-English-v1.0.bps to the original Japanese ROM:
Be-Bop-Highschool - Koukousei Gokuraku Densetsu (Japan).nes
Required source size: 262160 bytes (iNES file). CRC32: 17D50605.
Expected output size: 393232 bytes. CRC32: D2F09FDE.
Use a BPS-compatible patcher and save the output as a separate file.
Do not apply to an older English build or an already patched game.

Includes 616 identified text-bearing script entries, menus, endings,
staff credits, mixed-case font, functional Closed/Entrance signs, and
SuperWes title-screen credit. Decorative labels and original title artwork
remain Japanese.

POLYMEGA
Extract the BPS file from this ZIP. Put it in a folder named patch on a
USB drive or SD card. On Polymega, use Select Patch in the installed
game's Play menu. The game revision must match the patch.
Official instructions: https://polymega.com/pages/frequently-asked-questions

TESTING
SuperWes reports testing the translations using original cartridges on a
Polymega (October 19, 2026). Emulator checks also cover story/gameplay,
menus, passwords where applicable, and endings. Some checks used controlled
setups. Some optional paths remain unchecked; independent bilingual review
is still pending. This is an unofficial fan translation.

Start from a fresh boot. Old save states may restore old fonts or graphics.
These downloads contain patches and instructions, not game ROMs.
